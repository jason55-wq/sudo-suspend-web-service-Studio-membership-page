''' GPC-TC1.PY ---TC1  09/14 GPC-TC1-v2.PY 
GPC-TC1.PY-- member fn
http://vic8051.idv.tw/pgs.htm
Copyright (C) 2024   VICTOR uP LAB.
Status:release
=======================================================
'''
ver='GPC-TC1-v2.PY-- member fn'
import speech_recognition as sr
from gtts import gTTS
import pyautogui
import pygame
import time
import os
import sys
#----------------------------------------------------
f="c:\\program files\\google\\chrome\\application\\chrome.exe"
gpc_txt='是一套python 設計的程式，自訂關鍵字、開源(內部學員) 通用程式設計\
輔助工具，適合初學者自己自學、建構式教學、或是教學系統應用，\
可以經由 問答 關鍵字，找到適合的C程式 或是 資料庫 管理及應用'
#-------------------------------------
def vc():  #聲控輸入
    r=sr.Recognizer()
    with sr.Microphone() as source:
     print('Say ...', end='')
     audio=r.listen(source)
    try:
      ans=r.recognize_google(audio, language="zh-TW")  
      if len(ans)!=0:
         print(ans)
         sayx(ans)
         return ans
    except sr.UnknownValueError:
     print('x')
     return 'x'
    except sr.RequestError as e:
     print("No response : {0}".format(e))
     return 'x'
#----------------------------------------------------    
def py_mp3(fmp3): #圖控下說出MP3資料
 pygame.mixer.music.load(fmp3)
 pygame.mixer.music.play()
 while pygame.mixer.music.get_busy():
  time.sleep(0.3)
 pygame.mixer.music.stop()
 pygame.mixer.music.unload()
#----------------------------------------------------
def sayx(mess): #字串轉為語音輸出
 tts=gTTS(text=mess, lang='zh')#字串轉為語音資料 
 tts.save('temp.mp3')#語音資料存檔為MP3檔案 
 py_mp3('temp.mp3')  #說出MP3資料

#-----------------------------------------------------------------
def type(s):   #輸出文字檔
 with open(s,'r',encoding='utf8') as f:
  text=f.readlines()    
 for line in text:       
  tline=''
  tline+=line
  print(tline, end='') #不換行

#--------------------------------------------------------------
def find1(s): #測試搜尋單一檔案 t1.TXT
 #db='..\db_py'   
 with open('t1.TXT','r',encoding='utf8') as f:
  text=f.readlines()
#print(text)     
 for line in text:       
  tline=''
  tline+=line
#print(tline, end='')

  if tline.find(s) >=0:
   sayx('找到了')   
   print('find-----------------------------')
   for line in text:       
    tline=''
    tline+=line
    print(tline, end='')
  else: 
    sayx('查不到')
  break

# test KW=123------測試搜尋 N 個檔案------------------------------------
def find(fn, s):  # serch x files     
#with open('t1.TXT','r',encoding='utf8') as f:
 with open(fn,'r',encoding='utf8') as f:
  text=f.readlines()
#print(text)     
 for line in text:       
  tline=''
  tline+=line
#print(tline, end='')
  if tline.find(s) >=0: #-------------------------
   #print('找到了')
   print('file: ', end='')      
   print(fn)   
   print('find------'+s+'--------------') #find------define----
   for line in text:       
    tline=''
    tline+=line
    print(tline, end='')
  #else: print(' 查不到', end='')
   break # LINE 102: 注意內縮，一檔案只找到一筆資料就離開================

  #break #seek line1  
#break --seek  while lines

#-------------------------------------------
#dir=       "D:\PY1\GPC\DB_PY"
#dir=       "..\\DB_PY"
#dirPath = r"D:\PY1\GPC\DB_PY"

''' 找出單一目錄下的N個檔案名稱
dirPath = r"DB_PY"
path='DB_PY'
fns = [f for f in os.listdir(dirPath)
       if os.path.isfile(os.path.join(dirPath, f))]
'''       
#IP 聲控KW  OP TXT-------------------------------------
def gpc_ip():
 dirPath = r"DB_PY"
 path='DB_PY'  # 設定DB 名稱 ===================
 fns = [f for f in os.listdir(dirPath)
       if os.path.isfile(os.path.join(dirPath, f))]
    
 print('search...'+path, end='')
 #print(fns, end='')    #========================
 n=len(fns)
 print(n)
 
 hit.play()     
 a=vc() #a='99' a='測試'
 #time.sleep(1)
 if a!='x'  :#get key..serch     
    #sayx('我查一下')
    #sayx(a)
    #find1(a) #sayx('完成')  menu()
    for i in range(n):
     fn=fns[i]  #print(fn, end='')
     #fn=dirPath+'\\'+fns[i]
     #fn='DB_PY'+'\\'+fns[i]
     fn=path+'\\'+fns[i]     #合成完整檔案路徑
     find(fn, a)  #1 感應器  
 print('done--------------------')

#IP 聲控KW  OP TXT ----------------key in
def gpc_ip_key():
 dirPath = r"DB_PY"
 path='DB_PY'
 fns = [f for f in os.listdir(dirPath)
       if os.path.isfile(os.path.join(dirPath, f))]
 
 print('search...'+path)
 #print(fns, end='')
 n=len(fns)
 print(n, end='')
 
 hit.play() # a=vc() #a='99' a='測試'
 #time.sleep(1)
 a=input('input key word?')  #--------key in
 print(a) #if a!='x' key..serching
 print('key..searching ')
 for i in range(n):
     fn=fns[i] 
     fn=path+'\\'+fns[i]
     find(fn, a)  #1 感應器  
 print('done-------------------')
 
 
#-------------------------------------------------------------------
def test_ip():  # serch t1.TXT      
 hit.play()     
 a=vc() #a='99' a='測試'
 time.sleep(1)
 if a!='x'  :
    sayx('我查一下')
    sayx(a)
    find1(a)       
    #sayx('完成')
    menu()
    
#-------YT功能測試點歌 修正 系統 BUG-----------------------------
# https://www.youtube.com/watch?v=PS2jBuHeuc0
def cr_file1(s, wso ):
 with open(s,'a',encoding='utf8') as f:    
  #f.write(' \"D:\py1\gpc1\job\VR1.mp4\"')
  f.write(' \"'+wso+'\"')

def play_yt(wso):
 os.system('copy chrome.bat  exe1.bat')
 s='exe1.bat' 
 cr_file1(s,wso)
 #type(s)  
 os.system(s)

#wso='https://www.youtube.com/watch?v=PS2jBuHeuc0'
#play_yt(wso)
def dir_yt():
 print('1絕地任務')
 print('2輕音樂')
 print('3剛好遇見你-----')
 
#---------------------------------------------

# init-------------------------------------------------------------
def menu():
    screen.blit(bg, (0, 0))
    show = pointFont.render('Creat Your small CGPT system',  1,(255, 0, 0))
    screen.blit(show, (0, 15))
    show = pointFont.render('http://vic8051.idv.tw/pgs.htm', 1,(50, 255, 50))
    screen.blit(show, (0, 35))
    show = pointFont.render(ver, 1, (255, 0, 0))    
    screen.blit(show, (0, 55))
    show = pointFont.render('SPACE-VC  g n h-help', 1, (255, 100, 255))
    screen.blit(show, (0, 75))   
    pygame.display.flip()
#------------------------------------
#程式起點    
#-----------------------------------------------------
pygame.init()
hit  = pygame.mixer.Sound("py.wav")
#---------------------------------
pygame.mixer.init()
windowSize = [450, 450] # 400 300   240 326 ===
screen=pygame.display.set_mode(windowSize)
clock = pygame.time.Clock()
#bg = pygame.image.load("bg1.jpg")
bg = pygame.image.load("bg1.jpg")
bg = pygame.transform.scale(bg, windowSize)
pointFont = pygame.font.SysFont("Monospace", 25)#80
screen.blit(bg, (0, 0))
pygame.display.flip()
menu()
hit.play()

help='用GPC-- 0基礎，開始學Python 基礎程式，建構自己學習資料庫、最後設計出自己GPC 系統，學習各種程式語言或應用…'
#------------------------------------------
#os.system('type t1.txt')
# GO
#sayx('GPC 教學')

pyautogui.keyDown('shift')# eng key 切換為英文模式，使功能鍵有效
pyautogui.keyUp('shift')
print('===GPC 教學 測試'+ver+'===')
#loop--------------------------------------------
done=0 #False
while  not done:
    for event in pygame.event.get():
      #if event.type == pygame.MOUSEBUTTONDOWN: gpc_ip()          
      if event.type == pygame.QUIT:    done = True
      if event.type == pygame.KEYDOWN:  
       keys = pygame.key.get_pressed()       
       if keys[pygame.K_x]: done = True #結束
       if keys[pygame.K_s]: #執行批次檔
          hit.play()
          os.system('2303.bat')
       if keys[pygame.K_SPACE]:gpc_ip() #執行GPC
       
#====功能測試==============================       
       if keys[pygame.K_n]:  # 新NEWS   
          sayx('GPC 消息')
          os.system('pgs.bat')    
       if keys[pygame.K_g]:  # 指示說明      
          type('guide.txt')
          hit.play()          
          sayx('請先閱讀--課前準備+基礎參考')
       if keys[pygame.K_h]:   # HELP
          hit.play()
          print('----------------------------------')
          print(help)
          type('hcom.txt')#-------------------
       if keys[pygame.K_p]: #pen 執行記事本
          hit.play()          
          os.system('notepad')          
       if keys[pygame.K_w]: #執行chrome 
          hit.play()
          os.system('chrome.bat')
          
#====YT功能測試點歌==============================
       if keys[pygame.K_d]: 
          hit.play()
          dir_yt()
       if keys[pygame.K_1] or keys[pygame.K_9]:
          hit.play()
          dir_yt()
          wso='https://www.youtube.com/watch?v=PS2jBuHeuc0'
          play_yt(wso)

       if keys[pygame.K_2]:
          hit.play()
          dir_yt()
          wso='https://www.youtube.com/watch?v=5GroWAOn8h8&t=1970s'
          play_yt(wso)
          
       if keys[pygame.K_3]:
          hit.play()
          dir_yt()
          wso='https://www.youtube.com/watch?v=7q2KjXy5U6g'
          play_yt(wso)

#====GPC KW IP 由 key in  ======================             
       if keys[pygame.K_c]:gpc_ip_key()       
          
#====測試 YT 線上影片、連結 ===================                       
       if keys[pygame.K_t]: 
          hit.play()
          os.system('TEST1.bat')   
#-------------------------------------------------                 
       if keys[pygame.K_ESCAPE]: done = True    
# ---------------------------------------
    pygame.display.flip()
    clock.tick(60) 
pygame.quit()

#------------------------------------------------------------
#f="c:\program files\google\chrome\application\chrome.exe"
''' TEST1.bat       
"c:\program files\google\chrome\application\chrome.exe"
"c:\program files\google\chrome\application\chrome.exe" "http://vic8051.idv.tw/pic/cat.gif"
"c:\program files\google\chrome\application\chrome.exe"
"c:\program files\google\chrome\application\chrome.exe" "https://www.youtube.com/watch?v=8VbsXN2gyIs&t=50s"
'''
