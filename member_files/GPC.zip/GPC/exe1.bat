"c:\program files\google\chrome\application\chrome.exe"  
"c:\program files\google\chrome\application\chrome.exe" "https://www.youtube.com/watch?v=7q2KjXy5U6g"