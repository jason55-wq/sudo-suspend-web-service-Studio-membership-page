import os

# 搜尋關鍵字並輸出整個檔案內容
def find_and_print(keyword):
    dirPath = r"DB_PY"  # 搜尋資料夾
    fns = [f for f in os.listdir(dirPath) if os.path.isfile(os.path.join(dirPath, f))]

    found = False
    for fn in fns:
        filepath = os.path.join(dirPath, fn)
        with open(filepath, 'r', encoding='utf8') as f:
            lines = f.readlines()

        for line in lines:
            if keyword in line:
                print(f"=== 找到關鍵字：{keyword} 於檔案：{fn} ===")
                with open(filepath, 'r', encoding='utf8') as f:
                    print(f.read())
                found = True
                break  # 找到後不再搜尋其他檔案
        if found:
            break

    if not found:
        print(f"查不到關鍵字：{keyword}")

# 主程式
if __name__ == "__main__":
    while True:
        keyword = input("請輸入關鍵字（輸入 q 離開）：").strip()
        if keyword.lower() == 'q':
            break
        find_and_print(keyword)
