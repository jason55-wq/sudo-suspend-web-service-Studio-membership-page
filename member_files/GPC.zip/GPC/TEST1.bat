"c:\program files\google\chrome\application\chrome.exe"
"c:\program files\google\chrome\application\chrome.exe" "http://vic8051.idv.tw/pic/cat.gif"
"c:\program files\google\chrome\application\chrome.exe"
"c:\program files\google\chrome\application\chrome.exe" "https://www.youtube.com/watch?v=8VbsXN2gyIs&t=50s"





