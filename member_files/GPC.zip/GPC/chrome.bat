"c:\program files\google\chrome\application\chrome.exe"  
"c:\program files\google\chrome\application\chrome.exe"