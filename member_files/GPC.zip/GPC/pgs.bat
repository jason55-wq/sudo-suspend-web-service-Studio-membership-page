"c:\program files\google\chrome\application\chrome.exe"
"c:\program files\google\chrome\application\chrome.exe" "http://vic8051.idv.tw/pgs.htm"




